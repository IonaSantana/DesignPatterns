/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author ionasantana
 */
public class Trigo implements Cerveja{

    @Override
    public void produzir() {
         System.out.println("Cerveja de Trigo");
    }
}
