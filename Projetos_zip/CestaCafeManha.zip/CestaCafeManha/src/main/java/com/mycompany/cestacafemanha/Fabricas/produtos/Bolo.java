/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cestacafemanha.Fabricas.produtos;

import com.mycompany.cestacafemanha.Fabricas.FabricaDcoes;
import com.mycompany.cestacafemanha.Fabricas.Produto;

/**
 *
 * @author ionasantana
 */
public class Bolo extends FabricaDcoes{
    
    public Bolo() {
       this.setTipo("Bolo");
    }  
}
