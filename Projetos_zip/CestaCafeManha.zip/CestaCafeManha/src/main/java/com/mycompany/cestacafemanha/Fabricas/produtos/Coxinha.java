/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cestacafemanha.Fabricas.produtos;

import com.mycompany.cestacafemanha.Fabricas.FabricaSalgados;

/**
 *
 * @author ionasantana
 */
public class Coxinha extends FabricaSalgados{
    
    public Coxinha(){
        this.setTipo("Coxinha");
    }
}
