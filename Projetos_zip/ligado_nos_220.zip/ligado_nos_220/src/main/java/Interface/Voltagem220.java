/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author ionasantana
 */
public class Voltagem220 {
    private String energia220;
    
    public Voltagem220(){
        energia220 = "220v";
    }
    
    public String getEnergia(){
        return energia220;
    }
}
