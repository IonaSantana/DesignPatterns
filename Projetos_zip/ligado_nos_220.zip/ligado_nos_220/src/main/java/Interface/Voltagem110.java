/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author ionasantana
 */
public class Voltagem110 {
    private String energia110;
    
    public Voltagem110(){
        energia110 = "110v";
    }
    
    public String getEnergia(){
        return energia110;
    }
}
